import xbmcaddon

xbmcaddon.Addon().openSettings()
