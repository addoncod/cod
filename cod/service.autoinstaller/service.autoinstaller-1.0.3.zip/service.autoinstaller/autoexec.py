from plugin import Installer

m = Installer()

def main():
    m.create_folder(m.addon_data)
    
    if m.get_setting_bool("first_run"):
        first_run = m.dialog_yesno("This is the first time running the installer.\nDo you want create a list now?", yeslabel="Create List")
        if first_run:
            m.get_addon_list()
        m.set_setting("first_run", "false")
        
    elif m.get_setting_bool("activate_installer"):
        m.installer()
        
    elif m.get_setting_bool("list_creator"):
        m.get_addon_list()

if __name__ == "__main__":
    main()