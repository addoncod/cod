import xbmc
import xbmcvfs
import xbmcgui
import xbmcaddon
import json
import time

    
class Installer:
    
    #---Variables---#
    
    addon_id = xbmcaddon.Addon().getAddonInfo('id')
    addon_name = xbmcaddon.Addon().getAddonInfo('name')
    addon_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
    addon_data = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    addon_icon = xbmcaddon.Addon().getAddonInfo('icon')
    addon_fanart = xbmcaddon.Addon().getAddonInfo('fanart')
    addon_version = xbmcaddon.Addon().getAddonInfo('version')
    addons_path = xbmcvfs.translatePath('special://home/addons')
    get_setting = xbmcaddon.Addon().getSetting
    get_setting_bool = xbmcaddon.Addon().getSettingBool
    set_setting = xbmcaddon.Addon().setSetting
    main_json = addon_data + 'main.json'
    
    #---Log---#
    
    def log(self, message, error = ''):
        return xbmc.log(f'{message} {error}', xbmc.LOGINFO)
    
    #---Dialogs---#
    
    def dialog_ok(self, message):
        return xbmcgui.Dialog().ok(self.addon_name, message)
    
    def dialog_yesno(self, message, nolabel: str = 'No', yeslabel: str = 'Yes'):
        return xbmcgui.Dialog().yesno(self.addon_name, message, nolabel=nolabel, yeslabel=yeslabel)
    
    def dialog_yesno_custom(self, message: str, customlabel: str, nolabel: str = 'No', yeslabel: str = 'Yes'):
        return xbmcgui.Dialog().yesnocustom(self.addon_name, message, customlabel, nolabel=nolabel, yeslabel=yeslabel)
    
    def multi_dialog(self, header: str, names: list, choices: list, preselect: list = None):
        if preselect is None:
            preselect = []
        dialog = xbmcgui.Dialog()
        ret = dialog.multiselect(header, names, preselect=preselect)
        if ret:
            return [[names[choice], choices[choice]] for choice in ret]
        else:
            return None
    
    #---Various Methods---#
    
    def create_folder(self, folder_path):
        if not xbmcvfs.exists(folder_path):
            return xbmcvfs.mkdir(folder_path)
    
    def open_file(self, file_path):
         with open(file_path, 'r', encoding='utf-8', errors="ignore") as f:
             return f.read()
     
    def write_to_file(self, _file, _string):
         with open(_file, 'w', encoding='utf-8', errors="ignore") as f:
             f.write(_string)
    
    def get_json(self, page):
        return json.loads(self.open_file(page))
    
    def write_json(self, file_path, items):
       with open(file_path, 'w', encoding='utf-8') as f:
           json.dump({'items': items}, f, indent = 4)
    
    #---Installer Methods---#
    
    def installer(self):
        xbmc.sleep(5000)
        if not xbmcvfs.exists(self.main_json):
            create_now = self.dialog_yesno("There Was No Addon List Found.\nDo you want create a list now?", yeslabel="Create List")
            if create_now:
                self.get_addon_list()
            return 
        with open(self.main_json, 'r', encoding='utf-8', errors='ignore') as f:
            addon_list = json.loads(f.read())['items']
        failed = []
        for name, plugin_id in addon_list:
            install = self.install_addon(plugin_id)
            if install is not True:
                failed.append([name, plugin_id])
        if len(failed) == 0:
            self.dialog_ok('All Addons Installed Successfully')
            self.set_setting('activate_installer', 'false')
            return
        else:
            names = ''
            for name, plugin_id in failed:
                names += f'{name}, '
            names = names.rstrip(', ')
            try_again = self.dialog_yesno_custom(f'The following addons failed to install.\nWould You Like to Try Again?{names}', 'Turn Off', nolabel='Try Later', yeslabel='Try Now')
            if try_again == 1:
                self.installer()
            elif try_again == 2:
                self.set_setting('activate_installer', 'false')
            else:
                return   

    def install_addon(self, plugin_id):
        if xbmc.getCondVisibility(f'System.HasAddon({plugin_id})'):
            return True
        xbmc.executebuiltin(f'InstallAddon({plugin_id})')
        clicked = False
        start = time.time()
        timeout = 20
        while not self.isinstalled(plugin_id):
            if time.time() >= start + timeout:
                return False
            xbmc.sleep(500)
            if xbmc.getCondVisibility('Window.IsTopMost(yesnodialog)') and not clicked:
                xbmc.executebuiltin('SendClick(yesnodialog, 11)')
                clicked = True
        return True

    def get_addon_list(self):
        dirs, _ = xbmcvfs.listdir(self.addons_path)
        dirs.sort()
        for x in ['packages', 'temp']:
            dirs.remove(x)
        names = []
        for foldername in dirs:
            try :
                name = xbmcaddon.Addon(foldername).getAddonInfo('name')
            except:
                name = foldername
            names.append(name)
        preselect = []
        if xbmcvfs.exists(self.main_json):
            items = self.get_json(self.main_json)['items']
            for x in range(len(dirs)):
                if dirs[x] in [item[1] for item in items]:
                    preselect.append(x)
        addon_list = self.multi_dialog('Select Addons to Install', names, dirs, preselect=preselect)
        if addon_list is None:
            self.dialog_ok('No Items Were Selected.')
            return None
        self.write_json(self.main_json, addon_list)
        edit_again = self.dialog_yesno_custom(f'{len(addon_list)} Items Added to the List\nWould You Like to Edit the List Again?', 'Turn Off', nolabel='Edit Later', yeslabel='Edit Now')
        if edit_again == 1:
            self.get_addon_list()
        elif edit_again == 2:
            self.set_setting('list_creator', 'false')
        elif edit_again == 0:
            self.set_setting('list_creator', 'true')
        else:
            return

    def isinstalled(self, addonid):
        query = '{ "jsonrpc": "2.0", "id": 1, "method": "Addons.GetAddonDetails", "params": { "addonid": "%s", "properties" : ["name", "thumbnail", "fanart", "enabled", "installed", "path", "dependencies"] } }' % addonid
        addonDetails = xbmc.executeJSONRPC(query)
        details_result = json.loads(addonDetails)
        if "error" in details_result:
            return False
        elif details_result['result']['addon']['installed'] == True:
            return True
        else:
            return False